const { registerBlockType } = wp.blocks;
const { InspectorControls } = wp.blockEditor;
const { PanelBody, SelectControl, TextControl } = wp.components;
const { Fragment } = wp.element;

registerBlockType('top5/blogs', {
    title: 'Top 5 WordPress Blogs',
    icon: 'admin-post',
    category: 'widgets',
    attributes: {
        order: {
            type: 'string',
            default: 'DESC'
        },
        orderby: {
            type: 'string',
            default: 'publish_date'
        },
        number: {
            type: 'number',
            default: 5
        }
    },
    edit({ attributes, setAttributes }) {
        const { order, orderby, number } = attributes;

        return (
            <Fragment>
                <InspectorControls>
                    <PanelBody title="Settings">
                        <SelectControl
                            label="Order"
                            value={order}
                            options={[
                                { label: 'Ascending', value: 'ASC' },
                                { label: 'Descending', value: 'DESC' }
                            ]}
                            onChange={(value) => setAttributes({ order: value })}
                        />
                        <SelectControl
                            label="Order By"
                            value={orderby}
                            options={[
                                { label: 'Name', value: 'name' },
                                { label: 'Publish Date', value: 'publish_date' }
                            ]}
                            onChange={(value) => setAttributes({ orderby: value })}
                        />
                        <TextControl
                            label="Number of Blogs to Display"
                            type="number"
                            value={number}
                            onChange={(value) => setAttributes({ number: parseInt(value) })}
                        />
                    </PanelBody>
                </InspectorControls>
                <div className="top5-blogs-placeholder">
                    <p>Top 5 WordPress Blogs Block</p>
                </div>
            </Fragment>
        );
    },
    save() {
        return null; // Rendering in PHP
    }
});
