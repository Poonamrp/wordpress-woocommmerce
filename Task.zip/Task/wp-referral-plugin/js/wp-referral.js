jQuery(document).ready(function($) {
    $('#referral_code').on('blur', function() {
        var referral_code = $(this).val();
        $.ajax({
            url: wp_referral_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'validate_referral_code',
                referral_code: referral_code
            },
            success: function(response) {
                if (response.success) {
                    $('#referral_code_status').text('✓').css('color', 'green');
                } else {
                    $('#referral_code_status').text('✗').css('color', 'red');
                }
            }
        });
    });
});
