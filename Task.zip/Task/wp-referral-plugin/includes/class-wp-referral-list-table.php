<?php
if (!class_exists('WP_Referral_List_Table')) {

    class WP_Referral_List_Table extends WP_List_Table {

        public function __construct() {
            parent::__construct([
                'singular' => __('Referral', 'sp'),
                'plural'   => __('Referrals', 'sp'),
                'ajax'     => false
            ]);
        }

        public function get_columns() {
            return [
                'cb'               => '<input type="checkbox" />',
                'username'         => __('Username', 'sp'),
                'referral_username'=> __('Referral Username', 'sp'),
                'join_commission'  => __('Join Commission', 'sp'),
                'action'           => __('Action', 'sp')
            ];
        }

        public function prepare_items() {
            $columns = $this->get_columns();
            $hidden = [];
            $sortable = $this->get_sortable_columns();
            $this->_column_headers = [$columns, $hidden, $sortable];

            // Fetch data logic here

            $this->items = []; // Replace with actual data
        }

        public function column_default($item, $column_name) {
            switch ($column_name) {
                case 'username':
                case 'referral_username':
                case 'join_commission':
                    return $item[$column_name];
                case 'action':
                    return '<a href="#">Edit</a> | <a href="#">Delete</a>';
                default:
                    return print_r($item, true);
            }
        }

        public function column_cb($item) {
            return sprintf('<input type="checkbox" name="referral[]" value="%s" />', $item['ID']);
        }
    }
}
?>
