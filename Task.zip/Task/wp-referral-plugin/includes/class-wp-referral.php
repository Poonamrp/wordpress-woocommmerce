<?php
if (!class_exists('WP_Referral')) {

    class WP_Referral {

        public function __construct() {
            // Register shortcodes
            add_shortcode('wp_referral_form', [$this, 'render_referral_form']);

            // Enqueue scripts
            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);

            // Handle Ajax request
            add_action('wp_ajax_validate_referral_code', [$this, 'validate_referral_code']);
            add_action('wp_ajax_nopriv_validate_referral_code', [$this, 'validate_referral_code']);

            // Register admin settings
            add_action('admin_menu', [$this, 'register_admin_menu']);
            add_action('admin_init', [$this, 'register_settings']);
        }

        public function enqueue_scripts() {
            wp_enqueue_script('jquery');
            wp_enqueue_script('wp-referral-script', plugin_dir_url(__FILE__) . '../js/wp-referral.js', ['jquery'], null, true);
            wp_localize_script('wp-referral-script', 'wp_referral_ajax', ['ajax_url' => admin_url('admin-ajax.php')]);
        }

        public function render_referral_form() {
            ob_start();
            ?>
            <form id="wp-referral-form">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" name="first_name" required>
                
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" name="last_name" required>
                
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                
                <label for="referral_code">Referral Code</label>
                <input type="text" id="referral_code" name="referral_code">
                <span id="referral_code_status"></span>
                
                <input type="submit" value="Register">
            </form>
            <?php
            return ob_get_clean();
        }

        public function validate_referral_code() {
            $referral_code = sanitize_text_field($_POST['referral_code']);
            
            // Validate referral code logic here (e.g., check in the database)
            $is_valid = true; // This should be replaced with actual validation
            
            if ($is_valid) {
                wp_send_json_success();
            } else {
                wp_send_json_error();
            }
        }

        public function register_admin_menu() {
            add_menu_page('Referral Plugin Settings', 'Referral Plugin', 'manage_options', 'wp-referral-settings', [$this, 'admin_settings_page']);
            add_submenu_page('wp-referral-settings', 'Referral History', 'Referral History', 'manage_options', 'wp-referral-history', [$this, 'display_referral_history']);
        }

        public function register_settings() {
            register_setting('wp_referral_settings_group', 'wp_referral_join_commission');
        }

        public function admin_settings_page() {
            ?>
            <div class="wrap">
                <h1>Referral Plugin Settings</h1>
                <form method="post" action="options.php">
                    <?php settings_fields('wp_referral_settings_group'); ?>
                    <?php do_settings_sections('wp_referral_settings_group'); ?>
                    <table class="form-table">
                        <tr valign="top">
                            <th scope="row">Join Commission (Rs.)</th>
                            <td><input type="number" name="wp_referral_join_commission" value="<?php echo esc_attr(get_option('wp_referral_join_commission')); ?>" /></td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>
            <?php
        }

        public function display_referral_history() {
            $referralListTable = new WP_Referral_List_Table();
            $referralListTable->prepare_items();
            ?>
            <div class="wrap">
                <h2>Referral History</h2>
                <form method="post">
                    <?php
                    $referralListTable->display();
                    ?>
                </form>
            </div>
            <?php
        }
    }
}
?>
