<?php
/*
Plugin Name: WP Referral Plugin
Description: A simple referral plugin for WordPress.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include necessary files
include_once plugin_dir_path(__FILE__) . 'includes/class-wp-referral.php';

// Initialize the plugin
function wp_referral_plugin_init() {
    new WP_Referral();
}
add_action('plugins_loaded', 'wp_referral_plugin_init');
?>
