-- Schema Definitions

CREATE TABLE runner (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    main_distance DECIMAL(5, 2) NOT NULL,
    age INT NOT NULL,
    gender CHAR(1) NOT NULL
);

CREATE TABLE event (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    city VARCHAR(255) NOT NULL
);

CREATE TABLE runner_event (
    runner_id INT,
    event_id INT,
    FOREIGN KEY (runner_id) REFERENCES runner(id),
    FOREIGN KEY (event_id) REFERENCES event(id)
);

-- Query to Display Distance and Number of Runners by Age Category

SELECT 
    r.main_distance,
    COUNT(CASE WHEN r.age < 20 THEN 1 END) AS under_20,
    COUNT(CASE WHEN r.age BETWEEN 20 AND 29 THEN 1 END) AS age_20_29,
    COUNT(CASE WHEN r.age BETWEEN 30 AND 39 THEN 1 END) AS age_30_39,
    COUNT(CASE WHEN r.age BETWEEN 40 AND 49 THEN 1 END) AS age_40_49,
    COUNT(CASE WHEN r.age >= 50 THEN 1 END) AS over_50
FROM
    runner AS r
JOIN
    runner_event AS re ON r.id = re.runner_id
GROUP BY
    r.main_distance;
